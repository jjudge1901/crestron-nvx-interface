
import { CONFIG } from './config.js';

// Global State
let selectedDestinations = new Set();
let pendingSource = null;

// Endpoint State Management
const deviceState = new Map();

// Modal State
let pendingModeChangeDevice = null;

// Initialize Crestron Libraries
const CrComLib = window.CrComLib || {
    publishEvent: (type, id, value) => console.log(`[MOCK] Publish ${type} ID:${id} Value:${value}`),
    subscribeState: (type, id, cb) => console.log(`[MOCK] Subscribe ${type} ID:${id}`)
};

function initWebXPanel() {
    if (CONFIG.system.webXpanel) {
        console.log("Initializing Web XPanel...");
        if (window.WebXPanel) {
            window.WebXPanel.isActive = true;
            window.WebXPanel.host = CONFIG.system.processorIp;
            window.WebXPanel.ipId = CONFIG.system.ipId;
            console.log(`WebXPanel Configured: ${CONFIG.system.processorIp}:${CONFIG.system.ipId}`);
        } else {
            console.warn("WebXPanel library not found. Running in MOCK mode.");
        }
    }
}

function initUI() {
    // Initialize device state from config
    CONFIG.endpoints.forEach(ep => {
        deviceState.set(ep.id, {
            ...ep,
            isTx: false,
            online: true,
            name: ep.defaultName,
            sync: false,
            resolution: "",
            rebooting: false
        });
    });

    renderLists();
    subscribeAll();
    setupModal();

    updateClock();
    setInterval(updateClock, 60000);

    const powerBtn = document.getElementById('power-btn');
    if (powerBtn) {
        powerBtn.addEventListener('click', () => {
            sendSignal('b', 1, true);
            setTimeout(() => sendSignal('b', 1, false), 200);
        });
    }

    const takeBtn = document.getElementById('take-btn');
    if (takeBtn) {
        takeBtn.addEventListener('click', executeTake);
    }
}

function setupModal() {
    const modal = document.getElementById('modal-overlay');
    const confirmBtn = document.getElementById('modal-confirm');
    const cancelBtn = document.getElementById('modal-cancel');

    if (confirmBtn) {
        confirmBtn.addEventListener('click', () => {
            if (pendingModeChangeDevice) {
                executeModeChange(pendingModeChangeDevice);
            }
            closeModal();
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeModal);
    }
}

function openModal(device) {
    pendingModeChangeDevice = device;
    const modal = document.getElementById('modal-overlay');
    const nameEl = document.getElementById('modal-device-name');
    if (nameEl) nameEl.textContent = device.name;
    if (modal) modal.classList.remove('hidden');
}

function closeModal() {
    pendingModeChangeDevice = null;
    const modal = document.getElementById('modal-overlay');
    if (modal) modal.classList.add('hidden');
}

function subscribeAll() {
    CONFIG.endpoints.forEach(ep => {
        if (ep.modeJoin) {
            subscribeSignal('b', ep.modeJoin, (val) => {
                const state = deviceState.get(ep.id);
                // Only update if not currently "rebooting" (to avoid jumping around during boot)
                // OR if it is rebooting, maybe wait until online?
                // For now, allow updates but log it.
                if (state.isTx !== val) {
                    state.isTx = val;
                    if (!state.rebooting) renderLists();
                }
            });
        }

        if (ep.onlineJoin) {
            subscribeSignal('b', ep.onlineJoin, (val) => {
                const state = deviceState.get(ep.id);
                state.online = val;

                // If device comes back online, clear rebooting flag
                if (val && state.rebooting) {
                    state.rebooting = false;
                    renderLists(); // Re-render to clear styling
                }

                updateDeviceStatus(ep.id);
            });
        }

        if (ep.nameJoin) {
            subscribeSignal('s', ep.nameJoin, (val) => {
                if (val && val.length > 0) {
                    const state = deviceState.get(ep.id);
                    state.name = val;
                    updateDeviceText(ep.id);
                }
            });
        }

        if (ep.hdcpJoin) subscribeSignal('b', ep.hdcpJoin, (val) => updateHdcpStatus(ep.id, val));
        if (ep.join) subscribeSignal('n', ep.join, (val) => updateRoutingStatus(ep.id, val));

        if (ep.syncJoin) {
            subscribeSignal('b', ep.syncJoin, (val) => {
                const state = deviceState.get(ep.id);
                state.sync = val;
                updateSourceInfo(ep.id);
            });
        }
        if (ep.resJoin) {
            subscribeSignal('s', ep.resJoin, (val) => {
                const state = deviceState.get(ep.id);
                state.resolution = val;
                updateSourceInfo(ep.id);
            });
        }
    });
}

function renderLists() {
    const destGrid = document.getElementById('destinations-grid');
    const sourceList = document.getElementById('sources-list');

    if (!destGrid || !sourceList) return;

    destGrid.innerHTML = '';
    sourceList.innerHTML = '';

    selectedDestinations.clear();
    pendingSource = null;
    updateTakeButton();
    const sourcesSection = document.querySelector('.sources-section');
    if (sourcesSection) sourcesSection.classList.remove('active');

    deviceState.forEach(device => {
        if (device.isTx) {
            renderAsSource(device, sourceList);
        } else {
            renderAsDestination(device, destGrid);
        }
    });
}

function renderAsDestination(device, container) {
    const card = document.createElement('div');
    card.className = 'dest-card';
    card.id = `dest-${device.id}`;
    if (!device.online) card.classList.add('offline');
    if (device.rebooting) card.classList.add('rebooting');

    const hdcpId = `hdcp-${device.id}`;
    const modeId = `mode-${device.id}`;
    const rebootId = `reboot-${device.id}`;

    card.innerHTML = `
        <div style="display:flex; width:100%; gap:5px; margin-bottom:5px;">
            <button id="${modeId}" class="mode-btn">RX MODE</button>
        </div>
        <i class="fa-solid ${device.icon || 'fa-tv'} main-icon"></i>
        <h3 class="device-name">${device.name}</h3>
        <div class="routing-status">No Source</div>
        
        <div style="display:flex; flex-direction:column; gap:5px; width:100%; align-items:center; margin-top:10px;">
            <button id="${hdcpId}" class="hdcp-btn">
                <i class="fa-solid fa-lock"></i> HDCP: OFF
            </button>
            <button id="${rebootId}" class="reboot-btn">
                <i class="fa-solid fa-power-off"></i> Reboot
            </button>
        </div>
    `;

    card.addEventListener('click', (e) => {
        if (!e.target.closest('button')) toggleDestination(device);
    });

    // Synchronous Event Binding
    const hBtn = card.querySelector(`#${hdcpId}`);
    if (hBtn) hBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleHdcp(device);
    });

    const mBtn = card.querySelector(`#${modeId}`);
    if (mBtn) mBtn.addEventListener('click', (e) => {
        console.log("RX Mode Button Clicked", device.name);
        e.stopPropagation();
        requestModeChange(device);
    });

    const rBtn = card.querySelector(`#${rebootId}`);
    if (rBtn) rBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        rebootDevice(device);
    });

    container.appendChild(card);
}

function renderAsSource(device, container) {
    const card = document.createElement('div');
    card.className = 'source-card';
    card.id = `source-${device.id}`;
    if (!device.online) card.classList.add('offline');
    if (device.rebooting) card.classList.add('rebooting');

    const modeId = `mode-src-${device.id}`;

    card.innerHTML = `
        <button id="${modeId}" class="mode-btn tx-mode" style="margin-bottom:10px;">TX MODE</button>
        <i class="fa-solid ${device.icon || 'fa-box'}"></i>
        <h3 class="device-name">${device.name}</h3>
        <div class="source-info">
             <span class="sync-dot ${device.sync ? 'sync-active' : ''}"></span>
             <span class="res-text">${device.resolution || 'No Signal'}</span>
        </div>
    `;

    card.addEventListener('click', (e) => {
        if (!e.target.closest('button')) selectSource(device);
    });

    const mBtn = card.querySelector(`#${modeId}`);
    if (mBtn) mBtn.addEventListener('click', (e) => {
        console.log("TX Mode Button Clicked", device.name);
        e.stopPropagation();
        requestModeChange(device);
    });

    container.appendChild(card);
}

function updateDeviceStatus(id) {
    const state = deviceState.get(id);
    const destEl = document.getElementById(`dest-${id}`);
    const srcEl = document.getElementById(`source-${id}`);
    const target = destEl || srcEl;
    if (target) {
        if (state.online) target.classList.remove('offline');
        else target.classList.add('offline');
    }
}

function updateDeviceText(id) {
    const state = deviceState.get(id);
    const destEl = document.getElementById(`dest-${id}`);
    const srcEl = document.getElementById(`source-${id}`);
    const target = destEl || srcEl;
    if (target) {
        const h3 = target.querySelector('.device-name');
        if (h3) h3.textContent = state.name;
    }
}

function updateSourceInfo(id) {
    const state = deviceState.get(id);
    const srcEl = document.getElementById(`source-${id}`);
    if (!srcEl) return;
    const dot = srcEl.querySelector('.sync-dot');
    const res = srcEl.querySelector('.res-text');
    if (dot) {
        if (state.sync) dot.classList.add('sync-active');
        else dot.classList.remove('sync-active');
    }
    if (res) {
        res.textContent = state.resolution || 'No Signal';
    }
}

function updateRoutingStatus(destId, sourceId) {
    const destCard = document.getElementById(`dest-${destId}`);
    if (!destCard) return;
    const sourceDevice = deviceState.get(sourceId);
    const statusDiv = destCard.querySelector('.routing-status');
    if (!statusDiv) return;

    if (sourceDevice) {
        statusDiv.textContent = `Source: ${sourceDevice.name}`;
        statusDiv.style.color = 'var(--active-color)';
    } else if (sourceId === 0) {
        statusDiv.textContent = 'No Source';
        statusDiv.style.color = '#888';
    }
}

function toggleDestination(device) {
    if (selectedDestinations.has(device)) {
        selectedDestinations.delete(device);
        const el = document.getElementById(`dest-${device.id}`);
        if (el) el.classList.remove('selected');
    } else {
        selectedDestinations.add(device);
        const el = document.getElementById(`dest-${device.id}`);
        if (el) el.classList.add('selected');
    }
    updateTakeButton();
    const sourcesSection = document.querySelector('.sources-section');
    if (sourcesSection) {
        if (selectedDestinations.size > 0) {
            sourcesSection.classList.add('active');
            sourcesSection.scrollIntoView({ behavior: 'smooth', block: 'end' });
        } else {
            sourcesSection.classList.remove('active');
            pendingSource = null;
            document.querySelectorAll('.source-card').forEach(el => el.classList.remove('selected-source'));
        }
    }
}

function selectSource(device) {
    if (selectedDestinations.size === 0) return;
    pendingSource = device;
    document.querySelectorAll('.source-card').forEach(el => el.classList.remove('selected-source'));
    const el = document.getElementById(`source-${device.id}`);
    if (el) el.classList.add('selected-source');
    updateTakeButton();
}

function updateTakeButton() {
    const btn = document.getElementById('take-btn');
    if (!btn) return;
    if (selectedDestinations.size > 0 && pendingSource) {
        btn.disabled = false;
        const count = selectedDestinations.size;
        const destText = count === 1 ? Array.from(selectedDestinations)[0].name : `${count} Displays`;
        btn.innerHTML = `TAKE <br><small>${pendingSource.name} -> ${destText}</small>`;
    } else {
        btn.disabled = true;
        btn.innerHTML = 'TAKE <i class="fa-solid fa-check"></i>';
    }
}

function executeTake() {
    if (selectedDestinations.size === 0 || !pendingSource) return;
    console.log(`[TAKE] Routing Source ${pendingSource.name} to ${selectedDestinations.size} destinations.`);
    selectedDestinations.forEach(dest => {
        sendSignal('n', dest.join, pendingSource.id);
        updateRoutingStatus(dest.id, pendingSource.id);
    });
    pendingSource = null;
    selectedDestinations.clear();
    document.querySelectorAll('.dest-card').forEach(el => el.classList.remove('selected'));
    document.querySelectorAll('.source-card').forEach(el => el.classList.remove('selected-source'));
    const sourcesSection = document.querySelector('.sources-section');
    if (sourcesSection) sourcesSection.classList.remove('active');
    updateTakeButton();
}

function rebootDevice(device) {
    if (!device.rebootJoin) return;
    if (!confirm(`Are you sure you want to reboot ${device.name}?`)) return;
    sendSignal('b', device.rebootJoin, true); // Pulse
    setTimeout(() => sendSignal('b', device.rebootJoin, false), 200);
}

// --- Mode Change Logic ---
function requestModeChange(device) {
    if (!device.modeJoin) return;
    openModal(device);
}

function executeModeChange(device) {
    console.log(`[MODE] Changing Mode for ${device.name} and REBOOTING.`);

    // 1. Toggle Mode Pulse
    sendSignal('b', device.modeJoin, true);
    setTimeout(() => sendSignal('b', device.modeJoin, false), 100);

    // 2. Reboot Pulse
    if (device.rebootJoin) {
        setTimeout(() => {
            sendSignal('b', device.rebootJoin, true);
            setTimeout(() => sendSignal('b', device.rebootJoin, false), 200);
        }, 150); // Small delay after mode toggle
    }

    // 3. UI Update (Gray out)
    const state = deviceState.get(device.id);
    state.rebooting = true;
    renderLists();

    // 4. Fallback timeout to clear rebooting state if online feedback fails
    // (Optional: 120 seconds fallback)
    setTimeout(() => {
        if (state.rebooting) {
            state.rebooting = false;
            renderLists();
        }
    }, 120000);
}

function toggleHdcp(device) {
    if (!device.hdcpJoin) return;
    sendSignal('b', device.hdcpJoin, true);
    setTimeout(() => sendSignal('b', device.hdcpJoin, false), 100);
    const btn = document.getElementById(`hdcp-${device.id}`);
    if (btn) {
        const isActive = btn.classList.contains('active');
        updateHdcpStatus(device.id, !isActive);
    }
}

function updateHdcpStatus(destId, isActive) {
    const btn = document.getElementById(`hdcp-${destId}`);
    if (!btn) return;
    if (isActive) {
        btn.classList.add('active');
        btn.innerHTML = '<i class="fa-solid fa-lock"></i> HDCP: ON';
    } else {
        btn.classList.remove('active');
        btn.innerHTML = '<i class="fa-solid fa-lock-open"></i> HDCP: OFF';
    }
}

function sendSignal(type, id, value) {
    if (type === 'b') CrComLib.publishEvent('b', id.toString(), value);
    if (type === 'n') CrComLib.publishEvent('n', id.toString(), value);
    if (type === 's') CrComLib.publishEvent('s', id.toString(), value);
}

function subscribeSignal(type, id, callback) {
    if (type === 'b') CrComLib.subscribeState('b', id.toString(), callback);
    if (type === 'n') CrComLib.subscribeState('n', id.toString(), callback);
    if (type === 's') CrComLib.subscribeState('s', id.toString(), callback);
}

function updateClock() {
    const now = new Date();
    const clock = document.getElementById('clock');
    if (clock) clock.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

window.onload = () => {
    initWebXPanel();
    initUI();
};
