
/**
 * CRESTRON NVX CONTROL INTERFACE - CONFIGURATION
 * 
 * Update this file with your specific hardware details.
 * You can find the Join IDs by opening your old .vtp file in VT Pro-e.
 */

export const CONFIG = {
    system: {
        processorIp: "192.168.90.40",
        ipId: "04",
        webXpanel: true
    },

    // Unified Endpoints List (Remapped to fit within 32 Joins)
    endpoints: [
        // SOURCES (Transmitters)
        {
            id: 11,
            defaultName: "TX Cam",
            join: 11,       // Analog: Source Select 
            modeJoin: 1,    // Digital: TX/RX Mode (1-6)
            rebootJoin: 7,  // Digital: Reboot (7-12)
            onlineJoin: 13, // Digital: Online (13-18)
            hdcpJoin: 19,   // Digital: HDCP (19-24)
            syncJoin: 25,   // Digital: Sync (25-30)
            nameJoin: 1,    // Serial: Name (1-6)
            resJoin: 7,     // Serial: Res (7-12)
            icon: "fa-video"
        },
        {
            id: 12,
            defaultName: "TX Feed",
            join: 12,
            modeJoin: 2,
            rebootJoin: 8,
            onlineJoin: 14,
            hdcpJoin: 20,
            syncJoin: 26,
            nameJoin: 2,
            resJoin: 8,
            icon: "fa-satellite-dish"
        },
        {
            id: 13,
            defaultName: "TX DAW",
            join: 13,
            modeJoin: 3,
            rebootJoin: 9,
            onlineJoin: 15,
            hdcpJoin: 21,
            syncJoin: 27,
            nameJoin: 3,
            resJoin: 9,
            icon: "fa-music"
        },

        // DESTINATIONS (Receivers)
        {
            id: 21,
            defaultName: "RX Green Room",
            join: 21,
            modeJoin: 4,
            rebootJoin: 10,
            onlineJoin: 16,
            hdcpJoin: 22,
            syncJoin: 28,
            nameJoin: 4,
            resJoin: 10,
            icon: "fa-tv"
        },
        {
            id: 22,
            defaultName: "RX Stage Mgr",
            join: 22,
            modeJoin: 5,
            rebootJoin: 11,
            onlineJoin: 17,
            hdcpJoin: 23,
            syncJoin: 29,
            nameJoin: 5,
            resJoin: 11,
            icon: "fa-clipboard-user"
        },
        {
            id: 23,
            defaultName: "TX/RX FOH",
            join: 23,
            modeJoin: 6,
            rebootJoin: 12,
            onlineJoin: 18,
            hdcpJoin: 24,
            syncJoin: 30,
            nameJoin: 6,
            resJoin: 12,
            icon: "fa-sliders"
        }
    ]
};
